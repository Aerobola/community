package com.aerobola.apps.community;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Checked;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.List;

public class CompleteProfile extends AppCompatActivity implements Validator.ValidationListener {


    @Length(min = 3, message = "Enter atleast 3 characters.")
    private MaterialEditText fullnameEditText;

    @Checked
    private RadioGroup genderRadioGroup;

    @NotEmpty
    private MaterialEditText batchEditText;

    @Length(min = 10,message = "ID must have 10 characters.")
    private MaterialEditText classIDEditText;

    @NotEmpty
    private  MaterialEditText sessionEditText;

    @NotEmpty
    private  MaterialEditText phoneEditText;

    @NotEmpty
    private  MaterialEditText birthdateEditText;




   private Button submitButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_profile);
        String imageUri = "https://i.imgur.com/tGbaZCY.jpg";
        ImageView profile_image = (ImageView) findViewById(R.id.profileImageView);
        fullnameEditText=(MaterialEditText)findViewById(R.id.fullnameEditText);
        genderRadioGroup=(RadioGroup)findViewById(R.id.genderRadioGroup);
        batchEditText=(MaterialEditText)findViewById(R.id.batchEditText);
        classIDEditText=(MaterialEditText)findViewById(R.id.classIDEditText);
        sessionEditText=(MaterialEditText)findViewById(R.id.seesionEditText);
        phoneEditText=(MaterialEditText)findViewById(R.id.phoneEditText);
        birthdateEditText=(MaterialEditText)findViewById(R.id.birthdateEditText);
        submitButton=(Button)findViewById(R.id.submitButton);

        final Validator validator = new Validator(this);
        validator.setValidationListener(this);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validator.validate();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.logout) {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(CompleteProfile.this,LoginActivity.class));
            finish();

            return true;
        }
      return   super.onOptionsItemSelected(item);
    }

    @Override
    public void onValidationSucceeded() {

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);

            // Display error messages ;)
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }
}

